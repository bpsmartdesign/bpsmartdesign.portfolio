<section class="full-section">
  <div class="gallery">
    <?php for ($i = 0; $i < 12; $i++) : ?>
      <div class="g-img">
        <img src="http://via.placeholder.com/600x400" alt="Portfolio banner">
        <!-- <img src="<?= "Data/portfolio/$i.jpg" ?>" alt="Portfolio banner"> -->
      </div>
    <?php endfor; ?>
  </div>
</section>