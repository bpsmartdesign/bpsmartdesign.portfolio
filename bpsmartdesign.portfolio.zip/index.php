<?php
	header('Location: index');
	die()
?>